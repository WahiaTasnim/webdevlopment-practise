<?php 

$server_name = "localhost";
$user_name = "root";
$password = "";
$dbname = "web";

$conn = new mysqli($server_name, $user_name,$password,$dbname);
$sql =$conn->query("insert into student_info values(1,'wahia')");

if($sql===true){
	echo "Data inserted";
}
else{
	echo "Data is not inserted";
	}
//connection check


 ?>


