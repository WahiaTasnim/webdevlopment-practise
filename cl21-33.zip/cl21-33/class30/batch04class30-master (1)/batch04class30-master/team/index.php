<?php
  include_once('inc/header.php');
  
 
?>
<div class="container mt-5">
	<h2 class="text-center my-3">Our Team members</h2>
  <div class="row">
  	<div class="col-md-4">
  		<div class="card">
  			<img src="images/1.png" alt="" style="height: 300px;">
  			<div class="card-header">
  				<h2 class="card-title">Lorem ipsum dolor sit amet.</h2>
  				<h3 class="card-subtitle">Web Developer</h3>
  			</div>
  			<div class="card-body">
  				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, facilis hic ea ex quia nesciunt rerum molestias expedita tenetur eum.</p>
  			</div>
  		</div>
  	</div>
  	<div class="col-md-4">
  		<div class="card">
  			<img src="images/3.jpg" alt=""style="height: 300px;">
  			<div class="card-header">
  				<h2 class="card-title">Lorem ipsum dolor sit amet.</h2>
  				<h3 class="card-subtitle">Web Developer</h3>
  			</div>
  			<div class="card-body">
  				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, facilis hic ea ex quia nesciunt rerum molestias expedita tenetur eum.</p>
  			</div>
  		</div>

  	</div>
  	<div class="col-md-4">
  		<div class="card">
  			<img src="images/2.jpg" alt=""style="height: 300px;">
  			<div class="card-header">
  				<h2 class="card-title">Lorem ipsum dolor sit amet.</h2>
  				<h3 class="card-subtitle">Web Developer</h3>
  			</div>
  			<div class="card-body">
  				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, facilis hic ea ex quia nesciunt rerum molestias expedita tenetur eum.</p>
  			</div>
  		</div>
  	</div>
  </div>



</div>





















<?php include_once('inc/footer.php')?>