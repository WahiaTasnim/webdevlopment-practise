<?php 
include_once('header.php');
include_once('connection.php');


$data = $conn->query("select * from model_info");

 ?>

 <div class="container">
 	<h2 class="text-center m-5 text-info">Smartphone Information</h2>
 	<table class="table table-striped">
 		<thead>
 			<th>Sl</th>
        <th>Model Name</th>
        <th>Price</th>
        <th>Quantiy</th>		
 		</thead>
 		<tbody>
 			<?php  
 			$i=1;
 			while($dt = $data->fetch_assoc())
 				{?>
 			<tr>
        <td><?php echo $i++;?></td>
        <td><?php echo $dt['model_name']?></td>
        <td><?php echo $dt['price']?></td>
        <td><?php echo $dt['quantity']?></td>
      </tr>
      <?php }?>
 			
 		</tbody>
 	</table>
 </div>

 


