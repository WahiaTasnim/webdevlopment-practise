<?php 

include_once('header.php');
include_once('connection.php');

if(isset($_POST['submit']))
{
	$model_name = $_POST['name'];
	$job = $_POST['job'];
	$desc = $_POST['desc'];
	$img_name = $_FILES['image']['name'];
	$img_tmp_name = $_FILES['image']['tmp_name'];
	$img_name_array= explode('.',$img_name);
	$img_ext = end($img_name_array);
	$img_final_name = time().md5($img_name).$img_ext;

if(empty($name) || empty($job) || empty($desc))
{
	$error = "Field must not be empty";
}
else
{

	$conn->query("insert into model_info (model_name, price, quantity) values('$model_name',$price,$quantity)");
	$success = "Data inserted successfully";
}

}



 ?>




<div class="conatiner mt-5" >
	<?php 
if(isset($error)){
echo "<h3 class='alert alert-danger text-center'>".$error."</h3>";

}

 if(isset($success)){
      echo "<h3 class='alert alert-success text-center'>".$success."</h3>";
    }

	 ?>
 	<form action="" method="post" class="w-50 m-auto" enctype="multipart/form-data">
 		<div class="form-group">
 			<input type="text" class="form-control" name="name" placeholder="Enter Member Name">
 		</div>
 		<div class="form-group">
 			<input type="text" class="form-control" name="job" placeholder="Enter Job Title">
 		</div>
 		<div class="form-group">
 			<input type="file" class="form-control" name="image">
 		</div>
 		<div class="form-group">
 			<textarea name="desc" id="" cols="30" rows="10" class="form-control" placeholder="Enter Description"></textarea>
 		</div>
 		<div class="form-group">
 			<input type="submit" class="form-control btn-success" name="submit">
 		</div>
 	</form>
 </div>
 <?php 
include_once('footer.php');
 ?>