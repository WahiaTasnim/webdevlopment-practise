<?php
//indexed array
$ar= array("1","2","3");
echo "<pre>";
print_r($ar);
echo "</pre>";

//Associative array
$ar1 = array("Name"=>"Wahia","Unversity"=>"MBSTU","Dept"=>"ICT");
echo "<pre>";
print_r($ar1);
echo "</pre>";

//Multidimensional Array
$ar2 = array(
array("1","2","3"),
array("Name"=>"Wahia","Unversity"=>"MBSTU","Dept"=>"ICT")
);
  echo "<pre>";
print_r($ar2);
echo "</pre>";
$ar3 = array(
array("1","2","3"),
array("1","2","3"),
array("1","2","3"),
);

for($i=0;$i<=2;$i++)
{
	for($j=0;$j<=2;$j++)
	{
		echo $ar3[$i][$j]." ";
	}
	echo "<br>";

}

//sorting

$ar4 = array(5,4,2,1,3);
sort($ar4);
echo "<pre>";
print_r($ar4);
echo "</pre>";

rsort($ar4);
echo "<pre>";
print_r($ar4);
echo "</pre>";

ksort($ar1);
echo "<pre>";
print_r($ar1);
echo "</pre>";

krsort($ar1);
echo "<pre>";
print_r($ar1);
echo "</pre>";

function addition(){
	$x=2;
	$y=6;
	 echo $x+$y."<br>";
	}

	addition();

	echo $_SERVER['PHP_SELF']."<br>";


if(isset($_POST['submit']))
{
	$fname= $_POST['fname'];
	if(empty($fname))
	{
		echo "<h2 style='color:red'>Full name must not be empty</h2>";
	}
	else
	{
echo $_POST['fname']."<br>";
}
echo $_POST['email']."<br>";

echo "<pre>";
print_r($_FILES['image']['size']);
echo "</pre>";
}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title></title>
 	<link rel="stylesheet" href="">
 </head>
 <body>
 	<form action="" method="post" enctype="multipart/form-data">
 	<input type="text" placeholder="Full Name" name="fname">
 	<input type="email" placeholder="Email Address" name="email">
 	<input type="file" name="image">
 	<input type="submit" name="submit">
 </form>
 </body>
 </html>


 
