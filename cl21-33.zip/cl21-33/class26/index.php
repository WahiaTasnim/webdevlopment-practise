<?php
$a = array("1","2","3");
print_r($a);
echo "<br>";
  $st = "wahia tasnim";
 echo  strlen($st);
 echo "<br>";
 echo str_word_count($st);
 echo "<br>";
 echo strpos($st,"tasnim");
echo "<br>";
 $str = str_replace(" ","_", $st);
 $str= strtoupper($st);
 echo $str;
echo "<br>";
function square($a){

	echo $a*$a;

}

function color($cl,$pos){
	echo "<h2 style=$cl;$pos>Wahia</h2";
}
  
  square(5);
  color('color:blue','text-align:center');
 ?>