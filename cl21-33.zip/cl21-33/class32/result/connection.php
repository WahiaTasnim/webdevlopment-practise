<?php 

//function databaseconnection(){

$server_name = "localhost";
$user_name = "root";
$password = "";
$dbname = "result_system";

$conn = new mysqli($server_name, $user_name,$password,$dbname);
//}



 ?>