<?php 
include_once('connection.php');
//include_once('index.php');
function insertData(){
	global $conn;
	if(isset($_POST['submit']))
 {
 	//echo "ok";
 	$fname= $_POST['fname'];
 	$lname= $_POST['lname'];
 	$email= $_POST['email'];
 	$gender= $_POST['gender'];
 	$pass= $_POST['pass'];
 	$conpass= $_POST['conpass'];
 	$image= $_FILES['image']['name'];
 	$img_tmp_name =$_FILES['image']['tmp_name'];
 	$img_name_array= explode('.',$image);
 	$ext = end($img_name_array);
 	$img_final_name= time().md5($image).".".$ext;

 	if(empty($fname)|| empty($lname) || empty($email) || empty($pass) || empty($conpass))
 	{
 		$error="Feilds must not be empty";
 	}
 	else if ($pass != $conpass)
 	{
 		$error = "Password doesn't match";
 	}
 	else if(in_array($ext, ['jpg','png','gif','jpeg'])==false){
  		$error= "Image is invalid";
  	}
  	else
  	{
  		$conn->query("insert into reg_info(fname,lname,email,gender,pass,image) values('$fname','$lname','$email','$gender','$pass','$img_final_name')");
  		move_uploaded_file($img_tmp_name, 'images/'.$img_final_name);
  		$success =  "Data inserted successfully";
  	}
  	
 	
 }
}

function login(){
	global $conn;
	if(isset($_POST['submit'])){
  	session_start();
  	$pass= $_POST['pass'];
  	$email= $_POST['email'];
  	$data = $conn->query("select * from reg_info where email = '$email' and pass = '$pass'");
  	$row = $data->num_rows;
  	if(empty($email) || empty($pass )){
  		$error= "Field must not be empty";
  		//echo $error;
  	}
  	else if($row>0){
  		$_SESSION['email'] = $email;
  		$_SESSION['pass'] = $pass;
  		while($dt= $data->fetch_assoc()){
  			$_SESSION['fname'] = $dt['fname'];
  		$_SESSION['lname'] = $dt['lname'];
  		$_SESSION['image'] = $dt['image'];
  		//$_SESSION['pass'] = $pass;
  		}
  		header('location:profile.php');
  		//echo "You are logged in";

  	}
  	else{
  		//header('location:login.php');
  		$error = "user is not found! please check email or password";
  		header('location:login.php');
  	}
  	
  }
}

 ?>