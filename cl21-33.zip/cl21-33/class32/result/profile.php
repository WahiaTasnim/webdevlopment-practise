<?php 
include_once('bootstrap.php');
session_start();
if(empty($_SESSION['email'])|| empty($_SESSION['pass']))
{
	header('location:login.php');
}
else{

<img src="images/" alt="">
}

 ?>

 <a href="logout.php" class="btn btn-primary">Log Out</a>



 <?php 
include_once('footer.php');
 ?>