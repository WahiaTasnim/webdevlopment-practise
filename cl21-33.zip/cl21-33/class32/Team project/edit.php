<?php 
include_once('header.php');
include_once('connection.php');


$id = $_GET['id'];


$data= $conn->query("select * from member_info where id=$id ");
	
	//header("location:info.php");


if(isset($_POST['submit']))
{
	$name = $_POST['name'];
	$job = $_POST['job'];
	$desc = $_POST['desc'];
	$img_name = $_FILES['image']['name'];
	$img_tmp_name = $_FILES['image']['tmp_name'];
	$img_name_array= explode('.',$img_name);
	$img_ext = end($img_name_array);
	$img_final_name = time().md5($img_name).".".$img_ext;

if(empty($name) || empty($job) || empty($desc) || empty($img_name))
{
	$error = "Field must not be empty";
}
else if(in_array($img_ext,['jpg','jpeg','png','gif','JPG']) == false)
{
	echo "Invalid image!";
}
else
{

	$conn->query("update member_info set name='$name',job='$job',description='$desc', image='$img_final_name' where id=$id");
	move_uploaded_file($img_tmp_name,'images/'.$img_final_name);
	$success = "Data updated successfully";
}

}



 ?>




<div class="container mt-5" >
	<?php 
if(isset($error)){
echo "<h3 class='alert alert-danger text-center'>".$error."</h3>";

}

 if(isset($success)){
      echo "<h3 class='alert alert-success text-center'>".$success."</h3>";
    }

	 ?>
 	<form action="" method="post" class="w-50 m-auto" enctype="multipart/form-data">
 		<?php while($dt = $data->fetch_assoc()){?>
 		<div class="form-group">
 			<input type="text" class="form-control" name="name" placeholder="Enter Member Name" value="<?php echo $dt['name']?>">
 		</div>
 		<div class="form-group">
 			<input type="text" class="form-control" name="job" placeholder="Enter Job Title" value="<?php echo $dt['job']?>">
 		</div>
 		<div class="form-group">
 			<input type="file" class="form-control" name="image" value=">
 			<img src="images/<?php echo $dt['image']?>" alt="">
 		</div>
 		<div class="form-group">
 			<textarea name="desc" id="" cols="30" rows="10" class="form-control" placeholder="Enter Description"><?php echo $dt['description']?></textarea>
 		</div>
 		<div class="form-group">
 			<input type="submit" class="form-control btn-success" name="submit">
 		</div>
 	<?php } ?>
 	</form>
 </div>
 <?php 
include_once('footer.php');
 ?>