<?php

echo date('d-m-y')."<br>";
echo date('D-M-Y')."<br>";

date_default_timezone_set('Asia/Dhaka');
echo date('h:i:s A')."<br>";
echo time()."<br>";

$msg = "dgfgf gdgfg";
echo md5($msg)."<br>";
$ar = explode(' ',$msg);
print_r($ar);
$ar = implode(' ',$ar);
echo "<br>";
print_r($ar);
echo "<br>";
echo rand(0,100);
echo "<br>";
echo str_shuffle($msg);
echo "<br>";
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title></title>
 	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
 	<link rel="stylesheet" href="">
 </head>
 <body>
 	

<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
 </body>
 </html>


 
