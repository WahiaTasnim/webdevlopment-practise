<?php

	if(isset($_POST['submit'])){
		$fname = $_POST['fname'];
		$email = $_POST['email'];
		$pass = $_POST['pass'];
		$passLen = strlen($pass);
		if(empty($fname)){
			$fnameError =  "name can not be empty";
		}
		else if(empty($email)){
			$emailError =  "Email can not be empty";
		}
		else if(empty($pass)){
			$passError =  "Password can not be empty";
		}
		else if($passLen<6 || $passLen>10 ){
			$passLenError = "Password must be betweeen 6 and 10 characters long";
		}
		else
			$success = "ok";
	}
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link rel="stylesheet" href="">
</head>
<body>
	<div class="container mt-5">
		<div class="login-form w-50 m-auto p-5" style ="border: 1px solid #000; border-radius: 5px">
			<form action="" method="post">
				<h2 class="text-center bg-success text-light my-3 py-2">Sign Up Form</h2>
				<div class="form-group">
					<input type="text" class="form-control" placeholder="enter your name" name="fname">
					<?php
						if(!empty($fnameError)){
							echo '<p class="text-danger" style="font-size: 12px">'.$fnameError.'</p>';
						}
					?>
				</div>
				<div class="form-group">
					<input type="email" class="form-control" placeholder="enter your email" name="email">
					<?php
						if(!empty($emailError)){
							echo '<p class="text-danger" style="font-size: 12px">'.$emailError.'</p>';
						}
					?>
				</div>
				<div class="form-group">
					<input type="password" class="form-control" placeholder="enter your password" name="pass">
					<?php
						if(!empty($passLenError)){

							echo '<p class="text-danger" style="font-size: 12px">'.$passLenError.'</p>';
						}
						if(!empty($passError)){
							echo '<p class="text-danger" style="font-size: 12px">'.$passError.'</p>';
						}

					?>
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" name="submit">
				</div>
			</form>
		</div>
	</div>




	<script src="js/https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</body>
</html>