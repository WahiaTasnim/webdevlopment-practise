<?php


if(isset($_POST['submit']))
{
	$fname= $_POST['fname'];
	$email= $_POST['email'];
	$pass= $_POST['pass'];
$passlen= strlen($pass);
	if(empty($fname))
	{
		$fnameerror="<p style='color:red'>Full name must not be empty</p>";
		
	}	
else if(empty($email))
	{
		$emailerror= "<p style='color:red'>Email must not be empty</p>";
	}
	else if(empty($pass))
	{
		$passerror= "<p style='color:red'>Password must not be empty</p>";

	}

	else if($passlen<6|| $passlen>10)
	{
		$passlenerror= "<p style='color:red'>Password must be greater than 5 and less than 11</p>";
	}
	else
	{
echo "ALL Ok!";
}
}
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title></title>
 	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
 	<link rel="stylesheet" href="">
 </head>
 <body>
 	<div class="container mt-5">
 	<div class="login-form">
 	<form action="" method="post" enctype="multipart/form-data">

 		<h1 class="text-center bg-success p-3 ">Sign Up Form</h1>
 		<div class="form-group">
 	<input type="text" class="form-control" placeholder="Full Name" name="fname">

 	<?php
 	if(!empty($fnameerror))
 	{
 		echo $fnameerror;
 	}
 	?>

 </div>

 <div class="form-group">
 	<input type="email" class="form-control"  placeholder="Email Address" name="email">
 	<?php
 	if(!empty($emailerror))
 	{
 		echo $emailerror;
 	}
 	?>
 </div>

 <div class="form-group">
 	<input type="password" class="form-control"  placeholder="Password" name="pass">
 	<?php
 	if(!empty($passerror))
 	{
 		echo $passerror;
 	}
 	else if(!empty($passlenerror))
 	{
 		echo $passlenerror;
 	}
 	?>
 </div>
 	
 	<input type="submit" class="btn btn-success" name="submit">
 </form>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
 </body>
 </html>


 
