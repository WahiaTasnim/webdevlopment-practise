<?php
define("age", "18",true);
echo aGe; 
echo "<br>";

 $a = 5;
 $b = 5;
  if($a == $b)
  {
  	echo $a;
  }
 ?>